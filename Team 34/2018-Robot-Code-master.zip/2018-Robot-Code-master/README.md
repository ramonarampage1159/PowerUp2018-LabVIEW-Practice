# 2018-Robot-Code
FRC Team 34 Rockets 2018 Robot Code

## Tasks
- [x] Teleop
- [ ] Autonomous
- [x] Drive at Angle- Maraiah
- [x] Drive till distance

### Statistics

https://app.powerbi.com/view?r=eyJrIjoiMTY5OTFkMjAtZDFhOC00MTFjLTg5YTctNDk0ZGZkZDZmODc0IiwidCI6ImM5OGY2MDVjLTg0NjctNGRmNC05YzI2LTkxZTdhOWQ5NGEzMCIsImMiOjh9
