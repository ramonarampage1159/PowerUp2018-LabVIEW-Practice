# FRC2018CompetitionCode

Contributors
Jordan Yamada - Mentor; Coach
Joshua Bryant - Mentor; Coach
<<<<<<< HEAD
Harish Bommakanti - Software, Member
Sriram Bommakanti - Member; Software
Dinesh Saripalli - Member; Software
=======
Sriram Bommakanti - Member; Software
>>>>>>> parent of 0a4a223... Added me as a contributor
